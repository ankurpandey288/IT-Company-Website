﻿$(document).ready(function () {
    Getuserprofile();
});

function Getuserprofile() {
    var parm = {
        "id": parseInt($("#admin").val())
    };
    var josnstr = JSON.stringify(parm);
    $.ajax({
        type: "Post",
        dataType: "json",
        data: josnstr,
        contentType: "application/json; charset=utf-8",
        url: apiurl + 'api/CommonApi/Getuserprofile',
        success: function (data) {
            $('#username').append(data.name);
            $('#companyname').append(data.company);
        },
        error: function (result) {
            alert("Some error ocurred!");
        }
    });
};
