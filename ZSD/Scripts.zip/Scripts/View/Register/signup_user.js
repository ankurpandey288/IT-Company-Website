﻿$(document).ready(function () {
    //if ($.session.get("roleid") == undefined || $.session.get("roleid") == 0) {
    //    window.location.href = "/Login/Index/";
    // };
    GetCompany();
    $("#btnSubmit").click(function () {
        if (RegisterInLogin() == true) {
        } else {
            return false;
        }
    });
    $(document).ready(function () {
        $("#password, #ConfirmPassword").keyup(checkPasswordMatch);
    });
});

function checkPasswordMatch() {
    var password = $("#password").val();
    var confirmPassword = $("#ConfirmPassword").val();

    if (password != confirmPassword)
        $("#divCheckPasswordMatch").html("Passwords do not match!");
    else
        $("#divCheckPasswordMatch").html("Passwords match.");
}
function validatesignup() {
    var return_val = true;
    if ($('#ddlCompany option:selected').val() == 0) {
        $('#SpnCompany').show();
        return_val = false;
    } else {
        $('#SpnCompany').hide();
    }
    if ($('#txtmobile').val().trim() == "" || $('#txtmobile').val() == null) {
        $('#Spnmobile').show();
        return_val = false;
    } else {
        $('#Spnmobile').hide();
    }
    if ($('#txtemail').val().trim() == "" || $('#txtemail').val() == null) {
        $('#Spnemail').show();
        return_val = false;
    } else {
        $('#Spnemail').hide();
    }
    if ($('#txtadd').val().trim() == "" || $('#txtadd').val() == null) {
        $('#Spnadd').show();
        return_val = false;
    } else {
        $('#Spnadd').hide();
    }
    if ($('#txtpass').val().trim() == "" || $('#txtpass').val() == null) {
        $('#Spnpass').show();
        return_val = false;
    } else {
        $('#Spnpass').hide();
    }
    if ($('#txtcity').val().trim() == "" || $('#txtcity').val() == null) {
        $('#Spncity').show();
        return_val = false;
    } else {
        $('#Spncity').hide();
    }
    if ($('#txtcountry').val().trim() == "" || $('#txtcountry').val() == null) {
        $('#Spncountry').show();
        return_val = false;
    } else {
        $('#Spncountry').hide();
    }
    if ($('#txtdesig').val().trim() == "" || $('#txtdesig').val() == null) {
        $('#Spndesig').show();
        return_val = false;
    } else {
        $('#Spndesig').hide();
    }
    return return_val;
};

//add dataq to user login table
function RegisterInLogin() {
    var parm = {
        "email": $("#email").val(),
        "password": $("#password").val(),
        "created_by": 3,
        "role_id": 3
    };
    var josnstr = JSON.stringify(parm);
    $.ajax({
        type: "Post",
        data: josnstr,
        dataType: "json",
        contentType: "application/json",
        url: apiurl + "api/CommonApi/AddUserToLoginTbl",
        success: function (data) {
            if (data.status_id == 1) {
                RegisterUserToRegTbl();
            } else {
                alert(data.status);
            }
        },
        error: function (result) {
            alert("Error : data1");
        }
    });
};

//Add data to user registration table
function RegisterUserToRegTbl() {
    var parm = {
        "Company_Id": parseInt($("#ddlCompany option:selected").val()),
        "name": $("#name").val(),
        "Designation": $("#Designation").val(), 
        "Contact_Number": $("#phone").val(),
        "Address": $("#address").val(),
        "City": $("#city").val(),
        "Country": $("#country").val(),
        "Email_ID": $("#email").val(),
        "Created_By": parseInt("3")
    };
    var jsonstr = JSON.stringify(parm);
    $.ajax({
        type: "Post",
        data: jsonstr,
        dataType: "json",
        contentType: "application/json",
        url: apiurl + "api/CommonApi/AddUserToRegTbl",
        success: function (data) {
            if (data.status_id == 1) {
                swal({
                    title: "Thank You",
                    text: "We have successfully received your request for User registration. You will shortly receive the status updates on your registered Email",
                    icon: "success",
                    button: "Ok"
                }).then((value) => {
                    window.location.href = '/PartnerPortal/Login';
                });

            } else {
                swal("Error", data.status, "error");
            }
        },
        error: function (result) {
            alert("Error : data2");
        }
    });
};

function GetCompany() {
    $.ajax({
        type: "Get",
        dataType: "json",
        contentType: "application/json; charset=utf-8;",
        url: apiurl + "api/CommonApi/GetCompany",
        success: function (data) {
            $("#ddlCompany").html("").append('<option value="0">Select Company</option>');
            $(data).each(function () {
                $("#ddlCompany").append('<option value=' + this.Company_Id + '>' + this.Company_Name + '</option>');
            });
        },
        error: function (result) {
            alert("Error : data ddl ");
        }
    });
};