﻿$(document).ready(function () {
    $("#btnSubmit").click(function () {
        if (RegisterInLogin() == true) {
            //RegisterInLogin();
        } else {
            return false;
        }
    });
    $(document).ready(function () {
        $("#password, #ConfirmPassword").keyup(checkPasswordMatch);
    });
});
function checkPasswordMatch() {
    var password = $("#password").val();
    var confirmPassword = $("#ConfirmPassword").val();

    if (password != confirmPassword)
        $("#divCheckPasswordMatch").html("Passwords do not match!");
    else
        $("#divCheckPasswordMatch").html("Passwords match.");
}
function validatecompany() {
    var return_val = true;
    if ($('#txtcompany').val().trim() == "" || $('#txtcompany').val() == null) {
        $('#Spncompany').show();
        return_val = false;
    } else {
        $('#Spncompany').hide();
    }
    if ($('#txtestd').val().trim() == "" || $('#txtestd').val() == null) {
        $('#Spnestd').show();
        return_val = false;
    } else {
        $('#Spnestd').hide();
    }
    if ($('#txtCont').val().trim() == "" || $('#txtCont').val() == null) {
        $('#SpnCont').show();
        return_val = false;
    } else {
        $('#SpnCont').hide();
    }
    if ($('#txtEmail').val().trim() == "" || $('#txtEmail').val() == null) {
        $('#SpnEmail').show();
        return_val = false;
    } else {
        $('#SpnEmail').hide();
    }
    if ($('#txtnumber').val().trim() == "" || $('#txtnumber').val() == null) {
        $('#Spnnumber').show();
        return_val = false;
    } else {
        $('#Spnnumber').hide();
    }
    if ($('#txtpass').val().trim() == "" || $('#txtpass').val() == null) {
        $('#Spnpass').show();
        return_val = false;
    } else {
        $('#Spnpass').hide();
    }
    if ($('#txtaddress').val().trim() == "" || $('#txtaddress').val() == null) {
        $('#Spnaddress').show();
        return_val = false;
    } else {
        $('#Spnaddress').hide();
    }
    if ($('#txtcity').val().trim() == "" || $('#txtcity').val() == null) {
        $('#Spncity').show();
        return_val = false;
    } else {
        $('#Spncity').hide();
    }
    if ($('#ddlcountry option:selected').val() == 0) {
        $('#Spncountry').show();
        return_val = false;
    } else {
        $('#Spncountry').hide();
    }
    if ($('#ddlturn option:selected').val() == 0) {
        $('#Spnturn').show();
        return_val = false;
    } else {
        $('#Spnturn').hide();
    }
    if ($('#ddlemp option:selected').val() == 0) {
        $('#Spnemp').show();
        return_val = false;
    } else {
        $('#Spnemp').hide();
    }
    if ($('#txtdes').val().trim() == "" || $('#txtdes').val() == null) {
        $('#Spndes').show();
        return_val = false;
    } else {
        $('#Spndes').hide();
    }
    return return_val;
};

//add dataq to user login table
function RegisterInLogin() {
    var parm = {
        "email": $("#txtEmail").val(),
        "password": $("#txtpass").val(),
        "created_by":2,
        "role_id": 2
    };
    var josnstr = JSON.stringify(parm);
    $.ajax({
        type: "Post",
        data: josnstr,
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: apiurl + "api/CommonApi/AddUserToLoginTbl",
        success: function (data) {
            if (data.status_id == 1) {
                InsertCompany();
            } else {
                swal("Error", data.status, "error");
            }
        },
        error: function (result) {
            alert("Error : data1");
        }
    });
};

//Add data to user registration table
function InsertCompany() {
    var cn = $("#name").val();
    var cm = $("#email").val();
    var parm = {
        "Email_Id": $("#email").val(),
        "Contact_Name": $("#contactname").val(),
        "Contact_Number": $("#phone").val(),
        "Company_Name": $("#name").val(),
        "Establishmennt": parseInt($("#Estd").val()),
        "No_Of_Employees": ($("#ddlEmp option:selected").val()),
        "Address": $("#address").val(),
        "City": $("#city").val(),
        "Country_name": ($("#ddlcountry option:selected").val()),
        "Desc_Bussiness": $("#comment").val(),
        "Turn_over": $("#ddlturn option:selected").val()

    };
    var josnstr = JSON.stringify(parm);
    $.ajax({
        type: "Post",
        data: josnstr,
        dataType: "json",
        contentType: "application/json; charset=utf-8 ",
        url: apiurl + "api/CommonApi/AddNewCompany",
        success: function (data) {
            if (data.status_id == 1) {
                swal({
                    title: "Thank You",
                    text: "We have successfully received your request for partner registration. You will shortly receive the status updates on your registered Email",
                    icon: "success",
                    button: "Ok"
                }).then((value) => {
                    window.location.href = '/Home/Index';
                });
            }
            else {
                swal({
                    title: "Error",
                    text: "Error ",
                    icon: "error",
                    button: "Ok"
                });
            }
        },
        error: function (result) {
            alert("Error : data2");
        }
    });
};

//function SendCompRegMail(c_name, c_mail) {
//    var parm = {
//        "name": c_name,
//        "mail": c_mail
//    };
//    var josnstr = JSON.stringify(parm);
//    $.ajax({
//        type: "Post",
//        data: josnstr,
//        dataType: "json",
//        contentType: "application/json; charset=utf-8 ",
//        url: apiurl + "api/CommonApi/SendCompRegMail",
//        success: function (data) {
//            if (data.status_id == 1) {
//                swal({
//                    title: "Thank You",
//                    text: "We have successfully received your request for partner registration. You will shortly receive the status updates on your registered Email",
//                    icon: "success",
//                    button: "Ok"
//                }).then((value) => {
//                    window.location.href = '/Home/Index';
//                });
//            }
//            else {
//                swal({
//                    title: "Error",
//                    text: "Error sending mail.",
//                    icon: "error",
//                    button: "Ok"
//                });
//            }
//        },
//        error: function (result) {
//        }
//    });
//};