﻿var apiurl = 'https://localhost:44338/';
var localhost = 'https://localhost:44338/';
var filehost = 'https://localhost:44338/';
var filefolder = 'https://localhost:44338/BlogsImages';
var Controllerhost = 'https://localhost:44338/controller/';
var SalesMailid = "Ankurpandey288@gmail.com";


//var apiurl = 'https://zservicedesk.com/Zdesk/api';
//var localhost = 'https://zservicedesk.com/Zdesk/api';
//var filehost = 'https://zservicedesk.com/Zdesk/api';
//var filefolder = 'https://zservicedesk.com/Zdesk/BlogsImages';
//var Controllerhost = 'https://zservicedesk.com/Zdesk/api/controller/';
//var SalesMailid = "Ankurpandey288@gmail.com"