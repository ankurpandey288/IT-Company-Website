﻿////var apiurl = 'https://localhost:44338/';
////var localhost = 'https://localhost:44338/';
////var filehost = 'https://localhost:44338/';
////var filefolder = 'FileUpload/';
////var Controllerhost = 'https://localhost:44338/controller/';
////var SalesMailid = "Ankurpandey288@gmail.com";


var apiurl = 'https://zservicedesk.com/Zdesk';
var localhost = 'https://zservicedesk.com/Zdesk';
var filehost = 'https://zservicedesk.com/Zdesk';
var filefolder = 'FileUpload/';
var Controllerhost = 'https://zservicedesk.com/Zdesk/controller/';
var SalesMailid = "Ankurpandey288@gmail.com"